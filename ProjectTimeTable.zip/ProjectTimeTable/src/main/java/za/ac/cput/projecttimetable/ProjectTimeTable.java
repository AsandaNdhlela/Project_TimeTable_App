/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package za.ac.cput.projecttimetable;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import za.ac.cput.projecttimetable.dao.GroupsDAO;
import za.ac.cput.projecttimetable.gui.GroupsGUI;

/**
 *
 * @author Asanda Ndhlela
 */
public class ProjectTimeTable {

    public static void main(String[] args) {
        GroupsDAO dao = new GroupsDAO();
        dao.createTable();
        
        GroupsGUI runGui = new GroupsGUI();
        
        runGui.pack();
        runGui.setSize(900,400);
        runGui.setGroups();
        runGui.setDefaultCloseOperation(EXIT_ON_CLOSE);
        runGui.setVisible(true);
        
        
    }
}
