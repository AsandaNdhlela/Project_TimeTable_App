/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.projecttimetable.dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Asanda Ndhlela
 */
public class GroupsDBConnection {

    private static String username;
    private static String dbUrl;
    private static String password;

    public static Connection dbConnction() {

        try {
            username = "administrator";
            dbUrl = "jdbc:derby://localhost:1527/ProjectTimeTable";
            password = "admin";
            
            System.out.println("Connectiing to Database");
            return DriverManager.getConnection(dbUrl, username, password);
          
        } catch (SQLException err) {
            System.out.println("Error " + err);
        }
        return null;
    }
}
