/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.projecttimetable.gui;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import za.ac.cput.projecttimetable.dao.GroupsDAO;
import za.ac.cput.projecttimetable.domain.Groups;

/**
 *
 * @author Asanda Ndhlela
 */
public class GroupsGUI extends JFrame implements ActionListener {

    private JButton viewVenuesBtn, viewGroupBtn, viewLectureBtn, viewSubjectBtn, addNewBtn, changeBtn, deleteBtn;
    private DefaultTableModel tableModel;
    private JTable table;
    private JFrame frame;
    private JScrollPane scrollPane;
    private JPanel mainPanel, dashboardPanel, tablePanel, buttonsPanel;
    private JLabel dashboardLabel, tableLabel;

    public GroupsGUI() {

        super("Groups");

        //constructing JButtons
        viewVenuesBtn = new JButton("Venues");
        viewGroupBtn = new JButton("Groups");
        viewLectureBtn = new JButton("Lecturers");
        viewSubjectBtn = new JButton("Subjects");
        addNewBtn = new JButton("Add New");
        changeBtn = new JButton("Change");
        deleteBtn = new JButton("Delete");

        //constructing JLabels
        dashboardLabel = new JLabel("Admin");
        tableLabel = new JLabel("Venue");

        //constructing JPanels
        mainPanel = new JPanel();
        dashboardPanel = new JPanel();
        tablePanel = new JPanel();
        buttonsPanel = new JPanel();

        //constructing JTable
        tableModel = new DefaultTableModel();

        table = new JTable(tableModel);
        scrollPane = new JScrollPane(table);
        tableModel.addColumn("Group ID");
        tableModel.addColumn("Group Capacity");

        frame = new JFrame();
    }

    public void setGroups() {
        //setting the layout of the dashboard panel
        dashboardPanel.setLayout(new GridLayout(5, 1)); //4 rows and 1 column
        dashboardPanel.add(dashboardLabel);
        dashboardPanel.add(viewVenuesBtn);
        dashboardPanel.add(viewGroupBtn);
        dashboardPanel.add(viewLectureBtn);
        dashboardPanel.add(viewSubjectBtn);

        //setting the layout of the table panel
        tablePanel.setLayout(new GridLayout()); //rows and column
//        tablePanel.add(scrollPane);

        //setting the layout of the buttons panel
        buttonsPanel.setLayout(new GridLayout(1, 3)); //1 row and 3 columns
        buttonsPanel.add(addNewBtn);
        buttonsPanel.add(changeBtn);
        buttonsPanel.add(deleteBtn);

        //setting the layout of the main panel
        mainPanel.setLayout(new GridLayout(1, 2)); //rows and colums
        mainPanel.add(dashboardPanel);
        mainPanel.add(scrollPane);

        //adding panel to the frame
        this.add(mainPanel);
        this.add(buttonsPanel, BorderLayout.PAGE_END);

        //adding action listener to the buttons by using anonymous action listener
        addNewBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JPanel promt = new JPanel(new GridLayout(2, 2)); //3 rows and 2 columns
                JTextField groupID = new JTextField();
                JTextField groupCapacity = new JTextField();

                promt.add(new JLabel("Group ID: "));
                promt.add(groupID);
                promt.add(new JLabel("Group Capacity: "));
                promt.add(groupCapacity);

                int choiceResult = JOptionPane.showConfirmDialog(frame, promt, "Add New Group", JOptionPane.YES_NO_OPTION);

                if (choiceResult == JOptionPane.YES_OPTION) {

                    String group_id = groupID.getText();
                    int group_size = Integer.parseInt(groupCapacity.getText());

                    Groups groups = new Groups(group_id, group_size);

                    GroupsDAO dao = new GroupsDAO();
                    dao.addNew(groups);

                    ArrayList<Groups> groupsList = dao.readFromDB();
                    DefaultTableModel model = (DefaultTableModel) table.getModel();
                    model.setRowCount(0); // Clear the table

                    for (int i = 0; i < groupsList.size(); i++) {
                        model.addRow(new Object[]{groupsList.get(i).getGroupId(),
                            groupsList.get(i).getGroupCapacity()});

                    }

//                    model.addColumn(new Objetc["Group ID" , "Group Capacity"]);
                    tableModel.addRow(new Object[]{group_id, group_size});

                    dao.populateTable(table);
                }

            }

        });

        changeBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GroupsDAO dao = new GroupsDAO();
                
                JPanel promptChange = new JPanel(new GridLayout(2,2));
                JLabel changeID = new JLabel("Change capacity of ID : ");
                JLabel changeCapacity = new JLabel("Change capacity: ");
                JTextField changeIdTxt = new JTextField();
                JTextField changeCapacityTxt = new JTextField();
                
                promptChange.add(changeID);
                promptChange.add(changeIdTxt);
                promptChange.add(changeCapacity);
                promptChange.add(changeCapacityTxt);
                
                int choice = JOptionPane.showConfirmDialog(frame, promptChange,"Change Capacity", JOptionPane.YES_NO_OPTION);
                
               if(choice == JOptionPane.OK_OPTION){
                   String idOf = changeIdTxt.getText();
                   int newCapacity = Integer.parseInt(changeCapacityTxt.getText());
                   
                   Groups groups = new Groups(idOf,newCapacity);
                   dao.update(groups);
                   
                   //update the table
                   dao.populateTable(table);  
               }
            }
        });

        deleteBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GroupsDAO dao = new GroupsDAO();
                
                JPanel promptDeleteById = new JPanel(new GridLayout(1,2)); //1 row and 2 columns
                JLabel deletebyId_label = new JLabel("Delete by ID: ");
                JTextField deleteByIdTxt = new JTextField();
                
                promptDeleteById.add(deletebyId_label);
                promptDeleteById.add(deleteByIdTxt);
                
                int choice = JOptionPane.showConfirmDialog(frame,promptDeleteById,"Delete",JOptionPane.YES_NO_CANCEL_OPTION);
//                int selectedRow = table.getSelectedRow();

                if (choice == JOptionPane.YES_OPTION) {
//                    tableModel.removeRow(selectedRow);
                      String deleteId = deleteByIdTxt.getText();
                      
                      if(!deleteId.isEmpty()){
                        dao.delete(deleteId);  // Pass the ID to the DAO delete method

                        dao.populateTable(table);
                      }else{
                          JOptionPane.showMessageDialog(null,"No matching ID found");
                      }
               }
            }
        });

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
