/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.projecttimetable.domain;

/**
 *
 * @author Asanda Ndhlela
 */
public class Groups {

    
    private String groupId;
    private int groupCapacity;
    
        public Groups(String groupId, int groupCapacity) {
        this.groupId = groupId;
        this.groupCapacity = groupCapacity;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public int getGroupCapacity() {
        return groupCapacity;
    }

    public void setGroupCapacity(int groupCapacity) {
        this.groupCapacity = groupCapacity;
    }

    @Override
    public String toString() {
        return "Groups{" + "groupId=" + groupId + ", groupCapacity=" + groupCapacity + '}';
    }
        
        

    
}
